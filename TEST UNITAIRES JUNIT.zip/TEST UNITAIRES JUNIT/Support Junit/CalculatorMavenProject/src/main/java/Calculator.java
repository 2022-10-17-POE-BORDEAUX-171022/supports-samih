public class Calculator {

    public int integerDivision(int dividend, int divisor) {
        return dividend / divisor;
        //return dividend * divisor; Pour montrer que notre test unitaire va foirer
    }

    public int integerSubstraction(int number1, int number2) {
        return number1 - number2;
        //return dividend * divisor; Pour montrer que notre test unitaire va foirer
    }

}
