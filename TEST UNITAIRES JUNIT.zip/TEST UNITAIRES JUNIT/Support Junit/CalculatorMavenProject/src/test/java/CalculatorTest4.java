import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Test Math operations in Calculator Class")
public class CalculatorTest4 {

    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Executing @BeforeAll method");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("Executing @AfterAll method");
    }

    @BeforeEach
    void beforeEachTestMethod() {
        System.out.println("Executing @BeforeEach method");
        calculator = new Calculator();
    }

    @AfterEach
    void afterEachTestMethod() {
        System.out.println("Executing @AfterEach method");
    }

    @Disabled("TODO : still need to work on it")
    @DisplayName("Test 4 - 2 = 2")
    @Test
    void testIntegerSubstraction_WhenFourMinusTwo_shouldReturnTwo() {

        System.out.println("Running 4 - 2 = 2");
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 1;
        int result = calculator.integerSubstraction(number1, number2);

        assertEquals(2, result, () -> number1 + " - " + number2 + " did not produce " + expectedResult);
    }


    @DisplayName("Test 4/2 = 2")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo_2() {

        System.out.println("Running 4 / 2 = 2");
        // Arrange
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 2;

        // Act
        int result = calculator.integerDivision(number1, number2);

        // Assert
        assertEquals(expectedResult, result, "4/2 did not produce 2");

    }

    @DisplayName("Division by Zero")
    @Test
    void testIntegerDivision_WhenDividendIsDividedByZero_ShouldThrowArithmeticException() {
        System.out.println("Running Division by zero");

        int dividend = 4;
        int divisor = 0;

        String expectedExceptionMessage = "/ by zero";

        ArithmeticException actualException = assertThrows(ArithmeticException.class, () -> {

            calculator.integerDivision(dividend, divisor);
        }, "Division by zero should have thrown an Arithmetic exception.");

        assertEquals(expectedExceptionMessage, actualException.getMessage());
    }


    @DisplayName("Test integer substraction [number1, number2, expectedResult]")
    @ParameterizedTest
    @CsvSource({
            "33, 1, 32",
            "24, 1, 23",
            "54, 1, 53"
    })
    // Si t'as envie de passer des valeurs string
    /*@CsvSource({
            "Apple, Orange",
            "24, '' ", // une valeur vide
            "54," // une valeur null
    })*/
    void integerSubstractionParameters(int number1, int number2, int expectedResult) {

        System.out.println("Running Test" + number1 + " - " + number2  + " = " + expectedResult);
        int result = calculator.integerSubstraction(number1, number2);

        assertEquals(expectedResult, result, () -> number1 + " - " + number2 + " did not produce " + expectedResult);
    }
    // plus besoin de méthode qui renvoit un stream

}
