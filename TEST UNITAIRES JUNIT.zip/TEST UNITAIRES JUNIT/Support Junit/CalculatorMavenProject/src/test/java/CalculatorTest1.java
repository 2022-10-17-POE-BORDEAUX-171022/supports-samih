import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Test Math operations in Calculator Class")
public class CalculatorTest1 {

    @DisplayName("Test 4/2 = 2")
    @Test
    void integerDivision() {

        // FIRST UNIT TEST METHOD

        Calculator calculator = new Calculator();
        int result = calculator.integerDivision(4, 2);
        //assertEquals(2, result);

        // ASSERTIONS AND ASSERTION MSG
        assertEquals(2, result, "4/2 did not produce 2");

        // OTHER ASSERTIONS
        // make fail the test no matter the scenario
        // fail("");
        // assertNotEquals();

    }

    @DisplayName("Test 4 - 2 = 2")
    @Test
    void integerSubstraction() {
        Calculator calculator = new Calculator();
        int result = calculator.integerSubstraction(4, 2);
        assertEquals(2, result);
    }

    // LAZY ASSERT MESSAGES
    @DisplayName("Test 4 - 2 = 2")
    @Test
    void integerSubstraction2() {
        Calculator calculator = new Calculator();
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 1;
        int result = calculator.integerSubstraction(number1, number2);
        // attention car quand on fait ça, le code sera toujours executé même si le test est passé donc jamais utilisé (le msg)
        // donc faudrait améliorer les performances
        // assertEquals(2, result, number1 + " - " + number2 + " did not produce " + expectedResult);
        // Pour cela on va convertir le msg en lambda !
        // le code ne sera executé que si le test a foirer

        // MONTRER À LA CLASSE QUE CA FONCTIONNE EN FAISANT FOIRER LE TEST (FAIRE 5-2 = 1)
        assertEquals(2, result, () -> number1 + " - " + number2 + " did not produce " + expectedResult);
    }

    // NAMING UNIT TESTS

    @DisplayName("Division by zero")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo() {

        // FIRST UNIT TEST METHOD

        Calculator calculator = new Calculator();
        int result = calculator.integerDivision(4, 2);
        //assertEquals(2, result);

        // ASSERTIONS AND ASSERTION MSG
        assertEquals(2, result, "4/2 did not produce 2");

        // OTHER ASSERTIONS
        // make fail the test no matter the scenario
        // fail("");
        // assertNotEquals();

    }

    @Test
    void testIntegerDivision_WhenDividendIsDividedByZero_ShouldThrowArithmeticException() {

    }


    // Test Method Code Structure. Arrange, Act, Assert.

    @DisplayName("Test 4/2 = 2")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo_2() {

        // Arrange
        Calculator calculator = new Calculator();
        // En général les tests peuvent êtres assez complexe
        // C'est toujours intelligent de variabiliser les valeurs et retours attendus
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 2;

        // Act
        int result = calculator.integerDivision(number1, number2);

        // Assert
        assertEquals(expectedResult, result, "4/2 did not produce 2");

        // Ici la structure est parfaite
        // l'annotation displayName rend la description du test simple à comprendre
        // le code structuré est facilement maintenable

    }
}
