import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Test Math operations in Calculator Class")
public class CalculatorTest3 {

    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Executing @BeforeAll method");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("Executing @AfterAll method");
    }

    @BeforeEach
    void beforeEachTestMethod() {
        System.out.println("Executing @BeforeEach method");
        calculator = new Calculator();
    }

    @AfterEach
    void afterEachTestMethod() {
        System.out.println("Executing @AfterEach method");
    }

    @Disabled("TODO : still need to work on it")
    @DisplayName("Test 4 - 2 = 2")
    @Test
    void testIntegerSubstraction_WhenFourMinusTwo_shouldReturnTwo() {

        System.out.println("Running 4 - 2 = 2");
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 1;
        int result = calculator.integerSubstraction(number1, number2);

        assertEquals(2, result, () -> number1 + " - " + number2 + " did not produce " + expectedResult);
    }


    @DisplayName("Test 4/2 = 2")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo_2() {

        System.out.println("Running 4 / 2 = 2");
        // Arrange
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 2;

        // Act
        int result = calculator.integerDivision(number1, number2);

        // Assert
        assertEquals(expectedResult, result, "4/2 did not produce 2");

    }

    @DisplayName("Division by Zero")
    @Test
    void testIntegerDivision_WhenDividendIsDividedByZero_ShouldThrowArithmeticException() {
        System.out.println("Running Division by zero");

        int dividend = 4;
        int divisor = 0;

        String expectedExceptionMessage = "/ by zero";

        ArithmeticException actualException = assertThrows(ArithmeticException.class, () -> {

            calculator.integerDivision(dividend, divisor);
        }, "Division by zero should have thrown an Arithmetic exception.");

        assertEquals(expectedExceptionMessage, actualException.getMessage());
    }

    // ne pas oublier de modifier le displayName
    @DisplayName("Test integer substraction [number1, number2, expectedResult]")
    // Fonction test qui attend des paramètres
    @ParameterizedTest
    // Ici, je peux ne pas préciser la méthode source
    // mais ma méthode test doit avoir le même nom que la méthode source
    // Junit sera capable de la retrouver
    // @MethodSource("integerSubstractionParameters")
    @MethodSource()
    // void integerSubstraction(int number1, int number2, int expectedResult) {
    void integerSubstractionParameters(int number1, int number2, int expectedResult) {

        System.out.println("Running Test" + number1 + " - " + number2  + " = " + expectedResult);
        int result = calculator.integerSubstraction(number1, number2);

        assertEquals(expectedResult, result, () -> number1 + " - " + number2 + " did not produce " + expectedResult);
    }

    private static Stream<Arguments> integerSubstractionParameters() {
        return Stream.of(
                Arguments.of(33,1,32),
                Arguments.of(3,1,2),
                Arguments.of(10,3,7)
        );
    }

}
