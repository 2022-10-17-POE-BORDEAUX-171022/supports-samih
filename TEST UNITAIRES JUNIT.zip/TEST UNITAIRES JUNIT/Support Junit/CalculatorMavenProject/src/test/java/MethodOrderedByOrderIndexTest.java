import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MethodOrderedByOrderIndexTest {

    // Faut savoir que si je commente @TestMethodOrder
    // les méthodes ne seront pas executées dans l'ordre ci-dessous (le montrer aux étudiants)
    // Pour s'assurer que l'ordre d'execution est celui que l'on veut
    // on va utiliser l'annotation @Order

    @Order(1)
    @Test
    void TestB() {
        System.out.println("Running test B");
    }

    @Order(2)
    @Test
    void TestD() {
        System.out.println("Running test D");
    }

    @Order(3)
    @Test
    void TestC() {
        System.out.println("Running test C");
    }

    @Order(4)
    @Test
    void TestA() {
        System.out.println("Running test A");
    }


    /// CONCLUSION
    // BIEN QUE L'ON PUISSE CHOISIR L'ORDRE D'EXECUTION DES MÉTHODES
    // C'EST TOUJOURS IMPORTANTS QUE NOS MÉTHODES NE DÉPENDENT PAS DES UNES DES ORDRES
    // ET QU'ELLES PUISSENT S'EXECUTER SANS PROBLEME MÊME SI L'ORDRE D'EXECUTION EST RANDOM


}
