import org.junit.jupiter.api.*;

// @TestInstance(TestInstance.Lifecycle.PER_METHOD) // la config par défaut , une instance de classe pour chaque méthode executée
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MethodOrderedByOrderIndexTestChangeInstanceLifeCycle {

    StringBuilder completed = new StringBuilder();

    @AfterEach
    void afterEachMethod() {
        System.out.println("The state of the instance is " + completed);
    }

    @Order(1)
    @Test
    void TestB() {
        System.out.println("Running test B");
        completed.append("1");
    }

    @Order(2)
    @Test
    void TestD() {
        System.out.println("Running test D");
        completed.append("2");
    }

    @Order(3)
    @Test
    void TestC() {
        System.out.println("Running test C");
        completed.append("3");
    }

    @Order(4)
    @Test
    void TestA() {
        System.out.println("Running test A");
        completed.append("4");
    }


}
