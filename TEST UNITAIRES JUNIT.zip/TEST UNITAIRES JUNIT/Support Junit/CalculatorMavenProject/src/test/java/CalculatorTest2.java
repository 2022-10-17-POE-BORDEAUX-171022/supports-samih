import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DisplayName("Test Math operations in Calculator Class")
public class CalculatorTest2 {

    Calculator calculator;

    @BeforeAll
    static void setup() {
        System.out.println("Executing @BeforeAll method");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("Executing @AfterAll method");
    }

    @BeforeEach
    void beforeEachTestMethod() {
        System.out.println("Executing @BeforeEach method");
        calculator = new Calculator();
    }

    @AfterEach
    void afterEachTestMethod() {
        System.out.println("Executing @AfterEach method");
    }

    @Disabled("TODO : still need to work on it")
    @DisplayName("Test 4 - 2 = 2")
    @Test
    void testIntegerSubstraction_WhenFourMinusTwo_shouldReturnTwo() {

        System.out.println("Running 4 - 2 = 2");
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 1;
        int result = calculator.integerSubstraction(number1, number2);

        assertEquals(2, result, () -> number1 + " - " + number2 + " did not produce " + expectedResult);
    }


    @DisplayName("Test 4/2 = 2")
    @Test
    void testIntegerDivision_WhenFourDividedByTwo_ShouldReturnTwo_2() {

        System.out.println("Running 4 / 2 = 2");
        // Arrange
        int number1 = 4;
        int number2 = 2;
        int expectedResult = 2;

        // Act
        int result = calculator.integerDivision(number1, number2);

        // Assert
        assertEquals(expectedResult, result, "4/2 did not produce 2");

    }

    @DisplayName("Division by Zero")
    @Test
    void testIntegerDivision_WhenDividendIsDividedByZero_ShouldThrowArithmeticException() {
        System.out.println("Running Division by zero");

        // Arrange
        int dividend = 4;
        int divisor = 0;
        
        // si t'as envie de le faire fail
        //int divisor = 2;

        // l'exception que l'on attend
        String expectedExceptionMessage = "/ by zero";

        // Act & Assert
        // assert that throws an arithmetic exception
        // on doit préciser le type d'exception qu'on attends
        ArithmeticException actualException = assertThrows(ArithmeticException.class, () -> {

            // Act
            calculator.integerDivision(dividend, divisor);
        }, "Division by zero should have thrown an Arithmetic exception.");

        // Assert
        // check if exception message thrown
        // is the one expected
        assertEquals(expectedExceptionMessage, actualException.getMessage());
    }

}
