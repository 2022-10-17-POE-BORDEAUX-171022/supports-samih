package com.webstart;

public class Conditions {

    public static void main(String[] args) {

        // ce que l'on veut faire
        // si il fait plus de 30 degré
        // -> it is a hot day
        // sinon si il fait entre 20 et 30
        // -> it s a nice day
        // sinon
        // -> it is cold outside

        int temp = 32;
        // if statement has 3 clauses (statments)
        // else if et else toujours placer après le if


        if (temp > 30) {
            System.out.println("It is a hot day");
        } else if (temp < 30 && temp > 20) {
            System.out.println("It is a nice day");
        } else {
            System.out.println("It is cold outside");
        }


        // Let's simplify the code
        if (temp > 30) {
            System.out.println("It is a hot day");
        }// je suis allé à la ligne pour que mes deux clauses suivantes soient alignées avec le if
        else if (temp < 30) // ici on a enlevé la deuxième condition
            System.out.println("It is a nice day");
        else
            System.out.println("It is cold outside");


        // Simplify even more if statement

        // quand on déclare une variable dans un block elle n'est pas accessible à l'extérieur du block
        int income = 120_000;
        if (income > 100_000) {
            // j'utilise les curly brackets car je définis une variable
            boolean hasHighIncome = false;
        }

        // ici cette variable n'est pas accessible
        // comment solutionner ce problème?
        // System.out.println(hasHighIncome);

        // solution
        // déclarer la variable en dehors du if statement
        // et comme ça je peux même me débarrasser des curly brackets
        boolean hasHighIncome;
        if (income > 100_000)
            // j'utilise les curly brackets car je définis une variable
            hasHighIncome = false;
        else
            hasHighIncome = true;

        // mais ce code n'est pas terrible terrible
        // voici comment l'améliorer
        // on initialise la variable à false
        // dés le début
        boolean hasHighIncome2 = false;
        if (income > 100_000)
            hasHighIncome2 = true;

        // On peut simplifier encore plus
        boolean hasHighIncome3 = income > 100_000;

        // si on veut que ce soit encore plus clair:
        // on ajoutera les parenthèses
        boolean hasHighIncome4 = (income > 100_000);

    }

}
