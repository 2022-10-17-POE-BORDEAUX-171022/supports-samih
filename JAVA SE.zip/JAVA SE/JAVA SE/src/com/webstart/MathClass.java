package com.webstart;

public class MathClass {

    public static void main(String[] args) {

        // In Java, the Math class belongs to java.lang package.
        // The java.lang package is the default package for every program, there is no need to explicitly import the Math class in the program.
        // But all of its methods and variables are static.

        // classes prédéfinies qui nous permet de manipuler les chiffres en java plutôt facilement
        int result = Math.round(1.1F);

        System.out.println(result);

        // retourne l'entier supérieur
        result = (int) Math.ceil(1.1F);

        System.out.println(result);

        // retourne l'entier inférieur
        result = (int) Math.floor(1.1F);
        System.out.println(result);

        // retourne la plus grand valeur
        result = Math.max(1, 2);
        System.out.println(result);

        // retourne la plus petite valeur
        result = Math.min(1, 2);
        System.out.println(result);

        double randomNumber = Math.random(); // returns a double, a floating number between 0 and 1
        System.out.println(randomNumber);

        // Si on veut un chiffre aléatoire compris entre 0 et 100
        randomNumber = Math.random() * 100; // returns a double, a floating number between 0 and 1
        System.out.println(randomNumber);

        // et si je voulais arrondir mon chiffre aléatoire
        // scénario ou l'implicit casting ne fonctionne pas
        int roundedRandomNumber = (int) Math.round(Math.random() * 100); // ici erreur car le round renvoit un long et le casting implicit ne se fait pas
        // comme ont sait que le chiffre sera compris entre 0 et 100 on peut caster explicitement
        System.out.println(roundedRandomNumber);

        // Cas particulier

        // ici ca me renverra toujours 0 car je n'applique pas le cast à toute l'expression
        // Math.random() renvoit un chiffre entre 0 et 1 donc il va toujours arrondir à 0
        //int roundNumber = (int) Math.random() * 100;
        // pour éviter l'erreur du dessus on ajoute les parenthèses
        int roundNumber = (int) (Math.random() * 100);
        System.out.println(roundNumber);


    }

}
