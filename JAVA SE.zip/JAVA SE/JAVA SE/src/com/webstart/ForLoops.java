package com.webstart;

public class ForLoops {

    public static void main(String[] args) {

        for (int i = 0; i < 5; i++) {
            System.out.println("Hello World");
        }

        // Quand nous n'avons pas de block de code les curly brackets ne sont pas obligatoires
        for (int i = 0; i < 5; i++)
            System.out.println("Hello World");


    }

}
