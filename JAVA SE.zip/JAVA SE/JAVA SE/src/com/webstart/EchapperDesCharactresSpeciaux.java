package com.webstart;

public class EchapperDesCharactresSpeciaux {

    public static void main(String[] args) {


        // Escape Sequences
        // permet d'inclure des caractères spéciaux

        // Imaginez qu'on voulait ajouter les doubles quotes dans ma string
        String message = "Hello \"World\"";

        // Imaginez maintenant qu'on voulait spécifier un chemin et utiliser le backslash
        // on utiliserait les backslash
        String path = "c:\\Windows\\...";
        System.out.println(path);

        // to insert new line
        path = "c:\nWindows\\...";
        System.out.println(path);

        // to insert a tabulation
        path = "c:\tWindows\\...";
        System.out.println(path);

    }

}
