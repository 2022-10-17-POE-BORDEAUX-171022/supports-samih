package com.webstart;

import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    //
    // C'EST LE SUPPORT POUR REFACTORISER EN ORIENTÉ OBJET DANAS LA PARTIE 2 DU COURS
    //

    // Deux nouvelles méthodes ont été crées pour afficher le montant des mensualités
    // et le calendrier des paiements

    final static byte MONTHS_IN_YEAR = 12;
    final static byte PERCENT = 100;

    public static void main(String[] args) {

        int amount = (int) readNumber("Montant : ", 1000, 1_000_000);
        float annualInterest = (float) readNumber("Intérêt annuel :", 1, 30);
        byte years = (byte) readNumber("Nombre d'années : ", 1, 30);

        showMortgage(amount, annualInterest, years);
        showPaymentSchedule(amount, annualInterest, years);
    }

    private static void showPaymentSchedule(int amount, float annualInterest, byte years) {
        System.out.println();
        System.out.println("Calendrien de paiement : ");
        System.out.println("-------------------------");

        for(short month = 1; month <= years * MONTHS_IN_YEAR; month++) {
            double balance = calculateBalance(amount, annualInterest, years, month);
            System.out.println(NumberFormat.getCurrencyInstance().format(balance));
        }
    }

    private static void showMortgage(int amount, float annualInterest, byte years) {

        double mortgage =  calculateMortgage(amount, annualInterest, years);
        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);

        System.out.println(); // on ajoute une line vide
        System.out.println("Remboursement mensuel de l'emprunt");
        System.out.println("--------");
        System.out.println("Montant des mensualités: " + mortgageFormatted);
    }

    public static double readNumber(String prompt, double min, double max) {
        Scanner scanner = new Scanner(System.in);
        double value;
        while(true) {
            System.out.print(prompt);
            value = scanner.nextFloat();
            if(value >= min && value <= max)
                break;
            System.out.println("Enter a value between " + min + " and " + max );
        }

        return value;
    }

    public static double calculateMortgage(int amount, float annualInterest, byte years) {

        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        double mortgage = amount
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return mortgage;

    }

    // La méthode qui permettra de calculer le reste à payer
    public static double calculateBalance(
            int amount,
            float annualInterest,
            byte years,
            short numberOfPaymentMade) {

        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        // B = L[(1 + c)n - (1 + c)p]/[(1 + c)n - 1]
        double balance = amount
                * (Math.pow(1 + monthlyInterest, numberOfPayments) - Math.pow(1 + monthlyInterest, numberOfPaymentMade))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return balance;
    }


}
