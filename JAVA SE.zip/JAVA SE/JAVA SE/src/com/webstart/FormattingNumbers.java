package com.webstart;

import java.text.NumberFormat;

public class FormattingNumbers {

    public static void main(String[] args) {

        // How to format data in java
        // imaginons qu'on voulais afficher 13€
        // ou au lieu de 0.1 on veut afficher 10%
        //NumberFormat currency = New NumberFormat(); // on peut pas utiliser cette classe en l'instanciant car elle est abstrate


        //
        // Pour formatter les valeurs en euros
        //

        // on va donc utiliser une méthode factory du style .getCurrencyInstance()
        NumberFormat currency = NumberFormat.getCurrencyInstance(); // on récupère un objet NumberFormat qu'on stock dans la variable currency
        // cet objet a des méthodes pour formatter les valeurs
        String result = currency.format(1234567.891); // méthode overloadées
        System.out.println(result); // ça nous a fait ce qu'on voulait en ajoutant un symbole € et en remplacant le . par une virgule

        //
        // Pour formatter les valeurs en pourcentage
        //

        NumberFormat percent = NumberFormat.getPercentInstance();
        result = percent.format(0.1);
        System.out.println(result);

        //
        // Method chainy (chaining?)
        //

        // Puisque NumberFormat nous renvoit un objet instance de la classe NumberFormat
        // je peux directement appeler la méthode format depuis NumberFormat.getPercentInstance()
        result = NumberFormat.getPercentInstance().format(0.1); // on appel des méthodes à la chaine
        System.out.println(result);


    }

}
