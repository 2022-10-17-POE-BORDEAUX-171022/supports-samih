package com.webstart;

import java.util.Date;

public class PrimitiveAndReferenceTypes {

    public static void main(String[] args) {
	// write your code here
        // write your code here

        // Primitive VS REFERENCE

        // IL y a deux types de primitives en Java for storing simples values
        // Les reference qui permettent de stocker des objets complexes


        // précédemement on a utilisé un int pour stocker l'age mais ca prends beaucoup de place pour une petite valeur
        // donc on pourrait utiliser bute
        byte age = 30;
        int viewsCount = 123_456_789; // je peux utiliser l'underscore pour séparer les chiffres
        // int viewsCountDeux = 3_323_456_789; // ici j'ai une erreur car trop grand pour un int
        long viewsCountDeux = 3_323_456_789L; // je dois utiliser un long et ajouter un L à la fin pour que java comprenne que c'est pas un entier

        float price = 10.99F; // ici j'ai un erreur car il voit le chiffre comme un double donc je dois ajouter un suffixe

        char letter = 'A'; // on mets les guillemets simples pour un charactère et les doubles pour un mot

        boolean isConnected = false;

        // Les mots en orange sont des mots reservés en java donc on pourra pas appeler de variables avec ces noms la

        //
        // Tous les autres types sont des reference types
        //

        // L'objet Date

        // import java.util.Date; a été ajouté directement on a importé la classe Date
        Date now = new Date(); // ici le new permet d'allouer de la mémoire pour notre référence, la JRE le fait automatiquement pour nous
        // ici j'ai une instance de la classe date
        // -> object is an instance of a class
        now.getTime(); // return time component

        // Les types primitifs ne sont pas des objets donc si je fais age. il ne va rien nous proposer
        System.out.println(now); // j'entoure pas now dans des quotes sinon je verrai du texte dans la console

        // raccourcis pour faire System.out.println(now); -> sout
    }
}
