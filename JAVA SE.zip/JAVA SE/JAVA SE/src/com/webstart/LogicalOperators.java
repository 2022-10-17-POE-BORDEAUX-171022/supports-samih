package com.webstart;

public class LogicalOperators {

    public static void main(String[] args) {

        // Logical operators

        // combine multipal boolean expressions

        int temperature = 22;

        // Operator and
        boolean isWarm = temperature > 20 && temperature < 30;
        System.out.println(isWarm);

        // evaluation from left to right

        // Operator or
        // at least one condition is true
        boolean hasHightIncome = true;
        boolean hasGoodCredit = true;
        boolean isEligible = hasHightIncome || hasGoodCredit;
        System.out.println(isWarm);

        // Combine
        boolean hasCriminalRecord = false;
        isEligible = (hasHightIncome || hasGoodCredit) && !hasCriminalRecord;
        System.out.println(isEligible);

    }

}
