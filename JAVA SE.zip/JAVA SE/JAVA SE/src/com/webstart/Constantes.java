package com.webstart;

public class Constantes {

    public static void main(String[] args) {

        // pour créer des constantes on va utiliser le mot clef final
        // en l'utilisant et en initialisant une valeur
        // on ne pourra plus la changer

        // par convention on met nos constantes en majuscule

        final float PI = 3.14F;

    }

}
