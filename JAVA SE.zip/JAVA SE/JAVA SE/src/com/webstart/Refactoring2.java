package com.webstart;

import java.text.NumberFormat;
import java.util.Scanner;

public class Refactoring2 {

    public static void main(String[] args) {

        // Ici l'objectif c'est déviter la répétition du code et simplifier notre code
        // on va créer une méthode qui va rendre générique ce qui se passe dans chaque itération
        // le contrôle des valeurs
        // et le msg en cas de valeur erronnées


/*
        Scanner scanner = new Scanner(System.in);
*/

/*        int amount = 0;
        float annualInterest = 0;
        byte years = 0;*/

        // Contrôle du montant principal
        int amount = (int) readNumber("Amount", 1000, 1_000_000);
/*        while(true) {
            System.out.print("Somme principale : ");
            amount = scanner.nextInt();
            if (amount >= 1000 && amount <= 1_000_000)
                break;
            System.out.println("Enter a value between 1000 and 1_000_000");
        }*/

        // Contrôle du taux d'intérêts annuel
        float annualInterest = (float) readNumber("Annual Interest", 1, 30);
/*        while(true) {
            System.out.print("Taux d'intérêts Annuel : ");
            annualInterest = scanner.nextFloat();
            if(annualInterest >= 1 && annualInterest <= 30)
                break;
            System.out.println("Enter a value between 1 and 30");
        }*/

        // Contrôle du taux d'intérêts annuel
        byte years = (byte) readNumber("Period (Years)", 1, 30);
 /*       while(true) {
            System.out.print("Nombre d'années : ");
            years = scanner.nextByte();
            if(years >= 1 && years <= 30 )
                break;
            System.out.println("Enter a value between 1 and 30");
        }*/

        double mortgage =  calculateMortgage(amount, annualInterest, years);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Votre remboursement de prêt mensuel: " + mortgageFormatted);
    }

    public static double calculateMortgage(int amount, float annualInterest, byte years) {

        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;

        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        double mortgage = amount
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return mortgage;

    }


    public static double readNumber(String prompt, double min, double max) {
        Scanner scanner = new Scanner(System.in);
        double value;
        while(true) {
            System.out.print(prompt);
            value = scanner.nextFloat();
            if(value >= min && value <= max)
                break;
            System.out.println("Enter a value between " + min + " and " + max );
        }

        return value;
    }

}
