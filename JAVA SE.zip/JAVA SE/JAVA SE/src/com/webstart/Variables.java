package com.webstart;

public class Variables {

    public static void main(String[] args) {
        // write your code here

        // Initialiser une variable
        int age = 30; // on lui donne une valeur initiale
        // on a assigné la valeur 30 à la mémoire de la variable age

        //
        // TODO: penser à expliquer ce qu'est sout
        //

        System.out.println(age);

        // je peux modifier la valeur de la variable
        age = 40;

        System.out.println(age);

        // je peux déclarer les variables comme ça mais c'est pas vraiment une bonne pratique
        int birthYear = 1991, temperature = 25; // on retrouve la notation camelCase

        System.out.println(birthYear);
        System.out.println(temperature);

        // copier la valeur d'une variable dans une autre variable

        int herAge = age;



    }
}
