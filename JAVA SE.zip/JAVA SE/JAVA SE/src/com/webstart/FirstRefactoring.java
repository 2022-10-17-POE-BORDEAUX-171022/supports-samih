package com.webstart;

import java.text.NumberFormat;
import java.util.Scanner;

public class FirstRefactoring {

    // Dans cette partie on va reprendre l'exo qu'on avait fait ensemble
    // project2
    // et essayer de le refactoriser en quelques choses de plus maintenable et performant

    // pour ça on va décortiquer le code en méthode
    // en identifiant :
    // les lignes de codes qui vont toujours ensemble
    // repetitive paterns comme par exemple les boucles infinies

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // On a du sortir les variables des block pour une question de portée sinon
        // elle n'aurait pas été accessible..

        int amount = 0;
        float annualInterest = 0;
        byte years = 0;

        // Contrôle du montant principal
        while(true) {
            System.out.print("Somme principale : ");
            amount = scanner.nextInt();
            if (amount >= 1000 && amount <= 1_000_000)
                break;
            System.out.println("Enter a value between 1000 and 1_000_000");
        }

        // Contrôle du taux d'intérêts annuel
        while(true) {
            System.out.print("Taux d'intérêts Annuel : ");
            annualInterest = scanner.nextFloat();
            if(annualInterest >= 1 && annualInterest <= 30)
                break;
            System.out.println("Enter a value between 1 and 30");
        }

        // Contrôle du taux d'intérêts annuel
        while(true) {
            System.out.print("Nombre d'années : ");
            years = scanner.nextByte();
            if(years >= 1 && years <= 30 )
                break;
            System.out.println("Enter a value between 1 and 30");
        }

        double mortgage =  calculateMortgage(amount, annualInterest, years);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Votre remboursement de prêt mensuel: " + mortgageFormatted);
    }

    // On a regroupé dans ce block de code les lignes qui devaient être ensemble
    // Ce qui est cool avec le code ci dessous c'est que maintenant je peux calculer le remboursement mensuel d'un prêt
    // pour n'importe quel prêt et n'importe quel taux annuel d'intéret et année
    public static double calculateMortgage(int amount, float annualInterest, byte years) {

        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;

        // Attention on avait fait une erreur on avait mis
        // float pour numberOfPayments mais c'est short
        // on veut caster l'ensemble de la multiplication donc on mets les parenthèses
        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        double mortgage = amount
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return mortgage;

    }

    // C'est cool c'est la première partie de notre refactorisation
    // mais maintenant on aimerait bien se débarrasser des repetitive patterns



}
