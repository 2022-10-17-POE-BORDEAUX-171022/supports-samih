package com.webstart;

import java.util.Scanner;

public class ReadingInput {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in); // entre parenthèse de ou on va lire les données
        byte age = scanner.nextByte(); // pas mal de méthode disponible dans l'objet scanner imaginons qu'on récupère un byte
        System.out.println("You are " + age); // ici la conversion se fait automatiquement en java il va concaténer le texte avec le chiffre

        // ce serait bien maintenant de donner plus d'info dans la console et préciser que ce que l'on veut c'est l'age
        // donc on va juste ajouter
        // System.out.println("Age : "); avant de récupérer la données
        scanner = new Scanner(System.in);
        System.out.println("Age : ");
        age = scanner.nextByte();
        System.out.println("You are " + age);

        // vous observez que après Age: on a sauté une ligne quand on écris notre age
        // c'est la fonction println qui ajoute ce saut de ligne
        // si vous voulez éviter ça, faudra plutôt appeler la méthode print que println

        // problème
        // si on tape un chiffre floatant on aura une erreur
        // faudra appeler une autre méthode que nextByte

        // imaginons par exemple qu'on veut demander le prénom de la personne

        // la solution ce sera la méthode next() qui nous renvoit un string

        scanner = new Scanner(System.in);
        System.out.print("Name : ");
        String name = scanner.next();
        System.out.println("You are " + name);

        // imaginons maintenant que je tape le nom et le prénom?
        // on aura que le premier token qui apparaitra dans la console
        // faire la démonstration

        // explications
        // en fait la méthode next() lorsqu'elle est appelée une première fois renvoit le premier token (prénom)
        // si on l'appel une deuxième fois elle renverra le deuxième token (nom)

        // solution
        // si on veut tout récupérer
        // on va appeler la méthode nextLine

        scanner = new Scanner(System.in);
        System.out.print("Name : ");
        String fullName = scanner.nextLine();
        System.out.println("You are " + fullName);

        // Si on se retrouvez avec des espaces avant de rentrer le nom et le prénom, la méthode trim() serait plutôt intéressante à utiliser
        scanner = new Scanner(System.in);
        System.out.print("Name : ");
        fullName = scanner.nextLine().trim();
        System.out.println("You are " + fullName);


    }

}
