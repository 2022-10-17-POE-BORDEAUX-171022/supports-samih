package com.webstart;

public class CreatingMethods {
    // Creating methods
    // Les méthodes vont nous permettent d'oganiser notre code
    // en différents pièces réutilisables
    // et plus facilement maintenable

    public static void main(String[] args) {
        greetUser("Samih", "Habbani");

        // ici on stock le retour de notre méthode
        String msg = returnGreetUser("Samih", "Habbani");

    }

    // public acess modifiers
    // void ne retourne rien
    // static : la méthode appartient à la classe

    public static void greetUser(String firstName, String name) {
        System.out.println("Hello " + firstName + " " + name);
    }

    // cette méthode nous retournera quelque chose
    public static String returnGreetUser(String firstName, String name) {
        return "Hello " + firstName + " " + name; // return statement
    }
}
