package com.webstart;

public class Casting {

    public static void main(String[] args) {

        //
        // Implicit casting
        //
        short x = 1; // 2 bytes
        int y = x + 2; // 4 bytes

        // java va allouer automatiquement un nouvel espace mémoire pour la variable y
        // et comme dans y je peux avoir un chiffre sufisament grand pour la valeur short récupérée
        // et bien implicitement il va caster la valeur finale car il sait qu'il aura la place suffissante pour le résultat

        // la conversion suivante peut se faire automatiquement
        // byte > short > int > long

        System.out.println(y);

        // et si on avait des chiffres floatant

        double a = 1.1;
        // int b = a + 2; // ici on aura une erreur

        // la solution
        double b = a + 2;
        System.out.println(b);

        // que s'est-il passé?
        // java a transformé automatiquement le 2 du dessus en 2.0

        // byte > short > int > long > float > double

        // le casting implicite/automatique a lieu quand on a pas de perte de donnée


        //
        // Explicit casting
        //

        // et si on voulait quand même un integer à la fin

        double c = 1.1;
        int d = (int)c + 2; // explicite casting
        System.out.println(d);

        // Le casting explicite ne peut avoir lieu qu'avec des données compatibles
        // ici tous les types contiennt des chiffres

        // Que se passe-til si on souhaitais transformer un string en int?
        //String e = "1";
        //int f = (int)e + 2; // ici j'ai une erreur car je ne peux pas transformer directement un string avec un int
        //System.out.println(d);

        // On a pour cela ce qu'on appel des wrapper classes
        // elles appartienent au langage java.lang
        //Integer.parseInt(e); // this methode takes a string and returns an integer
        // Integer est la classe wrapper pour le type primitif int

        // on va avoir la même chose pour les short par exemple
        //Short.parseShort(e); // fait la même chose mais retourne un short

        //Float.parseFloat(e);
        //...

        // la solution finale

        String g = "1";
        int h = Integer.parseInt(g) + 2;
        System.out.println(h);

        // Pourquoi c'est un sujet important
        // ba par exemple quand on mettra en place des formulaires
        // on va surement récupérer des valeurs strings
        // on sera obligé de les convertir pour effectuer des calculs


        // il se passe quoi si g avait été un chiffre float à virgule

        g = "1.1";
        h = Integer.parseInt(g) + 2; // on aura une exception (erreur)
        System.out.println(h);

        // faudra utiliser la classe Double

        g = "1.1";
        Double i = Double.parseDouble(g) + 2; // on aura une exception (erreur)
        System.out.println(i);

        // Faudra tout de même stocker le résultat dans le bon type -> Double
    }

}
