package com.webstart;

public class Arrays {

    public static void main(String[] args) {
        // liste qui permettent de contenir plusieurs données

        // arrays are reference types
        int[] numbers = new int[5]; // on aura 5 chiffre

        // pour setter de valeurs
        numbers[0] = 1;
        numbers[1] = 2;

        // que se passe-til si on fait référence à un index inexistant
        //numbers[10] = 4; // une exeeotion sera lancée
        System.out.println(numbers); // on retoruve l'adresse de l'espace mémoire

        // accéder à une valeur

        // Quand tu fais .toString() tu vois quelle est implémentée plusieurs fois
        // quelle peut attendre différente type de valeur
        // on appel ce concept overloading() en programmation objet
        System.out.println(java.util.Arrays.toString(numbers));

        // on retrouve nos valeurs initialisées au départ, et pour les indices ou on na pas mis de valeur elle sont initialisée à zéro

        // on a une facon moins lourde de faire la même chose qu'au dessus :

        int[] listNumbers = {2, 3, 5, 1, 4};
        System.out.println(listNumbers.length); // pour avoir le nombre d'élément à l'intérieur

        System.out.println(java.util.Arrays.toString(listNumbers));

        // A savoir
        // les arrays ont une taille fixe
        // on ne peut pas ajouter ou supprimer d'éléménts à l'intérieur
        // pour le modifier faudra utiliser les classes collections qu'on verra plus tard

        // trier dans l'ordre ascendant
        java.util.Arrays.sort(listNumbers);
        System.out.println(java.util.Arrays.toString(listNumbers));

        // Je peux également afficher les valeurs en passant par l'index
        System.out.println(listNumbers[0]);

    }

}
