package com.webstart;

import java.util.Scanner;

public class FizzBuzz {

    public static void main(String[] args) {

        // Exercice
        // Demander aux élèves de rentrer un chiffre
        // si ce chiffre est divisible par 5 afficher en console Fizz
        // si ce chiffre est divisible par 3 afficher en console Buzz
        // si il est divisible par 5 et par 3 afficher FizzBuzz

        Scanner scanner = new Scanner(System.in);
        System.out.print("Number: ");
        int number = scanner.nextInt();


        // Première solution

        if(number % 5 == 0 && number % 3 == 0)
            System.out.println("FizzBuzz");
        else if(number % 5 == 0)
            System.out.println("Fizz");
        else if(number % 3 == 0)
            System.out.println("Buzz");
        else
            System.out.println(number);

        // Deuxième solution moins répétitive mais avec plus de nested conditions

        if(number % 5 == 0) {
            if (number % 3 == 0)
                System.out.println("FizzBuzz");
            else
                System.out.println("Fizz");
        }
        else if(number % 3 == 0)
            System.out.println("Buzz");
        else
            System.out.println(number);

        // demander une auter solution aux élèves

    }

}
