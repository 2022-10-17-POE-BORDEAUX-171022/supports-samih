package com.webstart;

import java.text.NumberFormat;
import java.util.Scanner;

public class Project2 {

    public static void main(String[] args) {

        // Reprendre le projet de calcul de remboursement de prêt mensuel

        // ajouter des controles

        //Préciser pour le montant que l'on attend un chiffre compris entre 1 et 1millions
        // tant que ce chiffre ne sera pas rentré on reposera la question à l'internaute

        // Pour le taux d'intérêt annuel
        // tant qu'on ne rentre pas un taux d'intéret supérieur à zero afficher un message et reposer la question

        // Pour la période d'emprunt
        // la règle sera un chiffre compris entre 1 et 30

        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;

        Scanner scanner = new Scanner(System.in);

        // On a du sortir les variables des block pour une questiond de portée sinon
        // elle n'aurait pas été accessible..

        int principal;
        float monthlyInterest;
        int numberOfPayments;

        // Contrôle du montant principal
        while(true) {
            System.out.print("Somme principale : ");
            principal = scanner.nextInt();
            if (principal >= 1000 && principal <= 1_000_000)
                break;
            System.out.println("Enter a value between 1000 and 1_000_000");
        }

        // Contrôle du taux d'intérêts annuel
        while(true) {
            System.out.print("Taux d'intérêts Annuel : ");
            float annualInterest = scanner.nextFloat();
            if(annualInterest >= 1 && annualInterest <= 30) {
                monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;
                break;
            }
            System.out.println("Enter a value between 1 and 30");
        }

        // Contrôle du taux d'intérêts annuel
        while(true) {
            System.out.print("Nombre d'années : ");
            byte years = scanner.nextByte();

            if(years >= 1 && years <= 30 ){
                numberOfPayments = years * MONTHS_IN_YEAR;
                break;
            }
            System.out.println("Enter a value between 1 and 30");
        }

        double mortgage = principal
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Votre remboursement de prêt mensuel: " + mortgageFormatted);


        // Le problème de ce code c'est qu'il est redeondant
        // compliqué
        // et il faut comprendre chaque block indépendament

        // on va voir pour améliorer ce code

        // Demander aux élèves une solution?

    }

}
