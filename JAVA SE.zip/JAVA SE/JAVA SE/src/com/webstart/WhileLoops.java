package com.webstart;

import java.util.Scanner;

public class WhileLoops {

    public static void main(String[] args) {

        int i = 0;

        while(i < 5) {
            System.out.println("Hello World");
            i++;
        }

        // For loops sont plus légères
        // utilisées plus les for loops quand on sait combien de fois on veut répéter un truc
        // et la boucle while quand on ne sait pas combien de fois on veut répeter quelque chose

        // Exemple on la boucle while serait plus apprécié

        // imagine qu'on voulait vérifier la saisie de l'utilisateur et executé du code
        // tant que l'utilisateur ne saisit pas ce qu'on lui demande

        String input = "";

        //while (input != "quit") // not working input is a string (refrence type) on ne peut pas comparé les variable de type référence avec une valeur
        // car on comparer l'adresse de la référence de l'objet string pas sa valeur
        // sinon a deux objets string ils seront stockées dans différents espace mémoire et on n'auront jamais la même adresse
        // donc on ne peut pas comparer leur valeur

        // on va donc devoir utiliser une méthode string

        Scanner scanner = new Scanner(System.in);

        while(!input.equals("quit")) {
            System.out.println("Input: ");
            // Scanner scanner = new Scanner(System.in);
            // on déplacer le scanner car sinon a chaque fois que l'user va rentrer une mauvaise valeur on va crééer un scanner
            // et consommer de la mémoire pour rien donc mettons le à l'extérieur de la loop
            input = scanner.next().toLowerCase(); // on met ca en minuscule pour que la comparaison fonctionne bien
            System.out.println(input);
        }


    }

}
