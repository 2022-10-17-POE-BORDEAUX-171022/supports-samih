package com.webstart;

public class Strings {

    public static void main(String[] args) {

        // String
        // définit dans java.lang pas d'import car automatiquement importé
        String message = new String("Hello World"); // redondant
        // voici la manière courte pour créer une string

        String myMessage = "Hello World";

            System.out.println(myMessage);

        // Concaténation
        myMessage = "    Hello World" + " !! ";

        // Méthodes objets
            System.out.println(myMessage.endsWith("!!"));
            System.out.println(myMessage.startsWith("!!"));

        // length of a string
            System.out.println(myMessage.length());
        // util quand on veut checker la saisie de l'internaute

        // indexOf
            System.out.println(myMessage.indexOf('H')); // renvoit 0 car la première occurence à lieu au premier caractère
            System.out.println(myMessage.indexOf('z')); // si pas de correspondance il renverra -1

        // replace
            System.out.println(myMessage.replace("!", "*"));

        // Ici ces valeurs sont appelés arguments
        // Beaucoup de dev ne savent pas la différence entre argument et paramètres
        // arguments sont les valeurs passées à nos méthodes
        // les paramèteres sont les trous que l'on définis sur nos méthodes

        // la méthode replace n'a pas modifié la valeur de myMessage si on regarde la valeur de la string actuelle
            System.out.println(myMessage);

        // Pourquoi? car les objets sont immuables en Java on ne peut pas les changer
        // donc les méthodes retournent toujours une nouvelle string

        // other methods
            System.out.println(myMessage.toLowerCase());
            System.out.println(myMessage.toUpperCase());

        // Trim remove white spaces
        // pour faire la démonstration ajouter des espaces blanc au début de la string
            System.out.println(myMessage.trim());

    }


}
