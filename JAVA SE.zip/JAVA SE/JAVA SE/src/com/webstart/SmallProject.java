package com.webstart;

import java.text.NumberFormat;
import java.util.Scanner;

public class SmallProject {

    public static void main(String[] args) {

        // Faire une application qui calcul un prêt
        // va falloir demander une somme
        // le taux d'intérêts annuel
        // le nombre de mensualités
        // de la calculer la hauteur des chaque mensualité de remboursement de prêt

        // Imaginon qu'on part sur un prêt de 30000
        // remboursable sur 5 ans
        // avec un taux annuel de 5%

        // Solution

        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;

        Scanner scanner = new Scanner(System.in);
        System.out.print("Somme principale : ");
        int principal = scanner.nextInt();

        System.out.print("Taux d'intérêts Annuel : ");
        float annualInterest = scanner.nextFloat();
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        System.out.print("Nombre d'années : ");
        byte years = scanner.nextByte();
        float numberOfPayments = years * MONTHS_IN_YEAR;

        double mortgage = principal
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);


        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Votre remboursement de prêt mensuel: " + mortgageFormatted);

        // Le calcul qu'on a fait il est cool
        // mais si je rentre une valeur négative par exemple au début
        // ba mon calcul ne sera pas bon
        // donc ce dont on aurait besoin
        // c'est de voir les conditions ce que l'on va voir juste après
    }


}
