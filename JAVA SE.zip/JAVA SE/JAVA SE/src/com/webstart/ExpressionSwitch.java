package com.webstart;

public class ExpressionSwitch {

    public static void main(String[] args) {

        // Switch statement

        String role = "Admin";

        switch(role) {

            case "Admin":
                System.out.println("You are an admin");
                break;

            case "Moderator":
                System.out.println("You are a moderator");
                break;

            default:
                System.out.println("You are a guest");
        }

        // on aurait pu également évaluer la valeur de role_number si c'était un int

        int role_number = 1;

        switch(role_number) {

            case 1:
                System.out.println("You are an admin");
                break;

            case 2:
                System.out.println("You are a moderator");
                break;

            default:
                System.out.println("You are a guest");
        }

    }

}
