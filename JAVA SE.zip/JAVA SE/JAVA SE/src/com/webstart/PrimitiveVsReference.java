package com.webstart;

import java.awt.*;

public class PrimitiveVsReference {

    public static void main(String[] args) {

        // La gestion de la mémoire n'est pas la même entre les types primitives et les types référence

        byte x = 1;
        byte y = x;

        // on a ici deux variables complétement indépendante qui alloue deux espaces mémoires différents
        // les deux sont indépendantes l'un de l'autre
        // si je modifie x cela n'aura pas d'impact sur y

        x = 2;
        System.out.println(y);

        // La différence avec les reférences
        // en java on a une classe Point

        Point point1 = new Point(1, 1);
        Point point2 = point1;

        // la différence avec les types primitifs
        // c'est que vous utiliser la classe Point java alloue de la mémoire pour socker Point(1,1)
        // et dans une autre espace mémoire, il va attacer à cette mémoire la variable point1 et mettre à l'intérieur l'adresse
        // de l'object Point(1,1)

        // c'est pour ca qu'on parle de reference type
        // car en mémoire on stocker la référence à un objet

        // ci-dessus point1 et point2 font référence au même objet
        // ils sont donc dépendant les uns des autres
        point1.x = 2;
            System.out.println(point2.x);

        // conclusion
        // ref type are copied by their reference
        // prim types are copied by their value

    }


}
