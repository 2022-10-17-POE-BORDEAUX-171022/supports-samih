package com.webstart;

import java.util.Arrays;

public class MultidimentionalArrays {

    public static void main(String[] args) {

        int[][] numbers = new int[2][3];

        numbers[0][0] = 1;

        System.out.println(java.util.Arrays.toString(numbers)); // ici on ne voit pas vraiment ce qu'il y a à l'intérieur de l'array donc il va falloir utiliser une autre méthode

        // Deep to String
        System.out.println(java.util.Arrays.deepToString(numbers));

        // Si on veut ajouter plus d'array à l'intérieur il suffira d'ajouter des dimensions int[][][] numbers = new int[2][3][5];


        // Et si on souhaite utiliser la synthaxe avec les accolades?

        int [][] listNumbers = { {1,2,3}, {4,5,6} };

        System.out.println(Arrays.deepToString(listNumbers));
    }

}
