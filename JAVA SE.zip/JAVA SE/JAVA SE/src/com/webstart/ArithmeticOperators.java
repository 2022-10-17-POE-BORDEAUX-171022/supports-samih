package com.webstart;

public class ArithmeticOperators {

    public static void main(String[] args) {

        // Addition
        int result = 10 + 3;
        System.out.println(result);

        // soustraction
        result = 10 - 3;
        System.out.println(result);

        // Multiplication
        result = 10 * 3;
        System.out.println(result);

        // Division
        result = 10 / 3;
        System.out.println(result);

        // en java quand on divise un chiffre impair par un chiffre impair
        // on obtient un chiffre impair

        // comment obtenir un chiffre à virgule
        // il va falloir convertir un float ou un double

        double secondResult = (double) 10 / (double) 3;
        System.out.println(secondResult);

        // Increment operator
        int x = 1;
        ++x;
        System.out.println(x);

        // il y a une différence si on l'utilise comme un préfixe ou un suffixe
        int a = 1;
        int b = a++;
        System.out.println(a);
        System.out.println(b);

        // en préfixant, b est égal a a et ensuite on incrémente de 1 a qui obtient une nouvelle valeur égale à 2
        // si on veut éviter ça faut préfixer

        int c = 1;
        int d = ++c;

        System.out.println(c);
        System.out.println(d);


        // comment je fais si je veux incrémenter de plus de 1 par exemple 2
        // faudrait faire
        x = x + 2;

        // raccourcis
        x += 2;

        // on va avoir la même chose pour les autres opérateurs
        x -=2;
        x *= 2;
        x /= 2;

        // Decrement operator

    }


}
