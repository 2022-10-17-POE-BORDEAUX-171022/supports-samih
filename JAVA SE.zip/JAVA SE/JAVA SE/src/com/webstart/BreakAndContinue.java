package com.webstart;

import java.util.Scanner;

public class BreakAndContinue {

    public static void main(String[] args) {

        // BREAK AND CONTINUE

        // Imaginez qu'on voulait contrôler les saisies de l'internaute
        // tant qu'il tape pas quit le programme continue
        // si il tape pass je vais à la saisie suivante sans montrer la saisie dans la console
        String input = "";

        Scanner scanner = new Scanner(System.in);

        while(true) { // attentionn à bien mettre en place un break dans l'itération pour ne pas avoir de boucle infinie

            System.out.println("Input: ");
            input = scanner.next().toLowerCase();

            if(input.equals("pass"))
                continue;

            if(input.equals("quit"))
                break;

            System.out.println(input);
        }

    }

}
