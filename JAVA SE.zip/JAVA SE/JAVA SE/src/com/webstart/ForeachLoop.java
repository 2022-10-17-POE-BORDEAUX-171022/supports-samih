package com.webstart;

public class ForeachLoop {

    public static void main(String[] args) {

        // FOR EACH LOOP

        String[] fruits = {"Apple", "Mango", "Orange"};

        // SI on souhaite itérer dans la table on pourrait le faire avec n'importe quelle type de loop
        // mais plutôt intéressant avec le foreach loop

        // si on voulait parcourir le tableau avec une boucle classique
        for (int i = 0; i < fruits.length; i++) {
            System.out.println(fruits[i]);
        }


        // Avec une for each loop

        for(String fruit : fruits)
            System.out.println(fruit);


        // Les inconvénients de la for each loop
        // c'est que je suis plus libre avec une boucle for classique
        // je pourrai par exemple parcourir la liste depuis la fin du tableau
        // ce n'est pas le cas avec la boucle for each

        // pareil je ne récupère l'index des éléments de la lise

    }
}
