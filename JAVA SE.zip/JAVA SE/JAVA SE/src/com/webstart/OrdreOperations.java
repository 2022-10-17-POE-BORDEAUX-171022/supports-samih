package com.webstart;

public class OrdreOperations {

    public static void main(String[] args) {

        // ordre d'opération
        int x = 10 + 3 * 2;
        System.out.println(x);

        // ici 3*2 est évalué en premier ensuite se fait l'adition c'est pour cela qu'on obtient 16

        // si on veut changer l'odre d'opération

        x = (10 + 3) * 2;

        // donc l'ordre c'est en premier :
        // ()
        // * et /
        // - et +

    }

}
