package com.webstart;

public class OperateurTernaire {

    public static void main(String[] args) {

        int income = 120_000;
        String className;
        if (income > 100_000) {
            className = "First";
        } else {
            className = "Economy";
        }

        // Ce code ne fait pas très pros, on pourrait le simplifier en utilisant l'opérateur ternaire
        String className2 = income > 100_000 ? "First" : "Economy";


    }

}
