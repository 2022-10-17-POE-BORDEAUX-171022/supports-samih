package com.webstart;

import java.util.Scanner;

public class DoWhile {

    public static void main(String[] args) {

        // La différence entre do while loops et while loops
        // c'est que la condition dans un do while est vérifiée à la fin
        // donc le code est toujours executé au moins une fois

        // Contrairement a while loops ou la condition est verifiée en premier
        // et le code ne sera donc potentiellement jamais executé si la condition de départ n'est pas vraie

        String input = "";

        Scanner scanner = new Scanner(System.in);

        do {
            System.out.println("Input: ");
            input = scanner.next().toLowerCase();
            System.out.println(input);
        } while(!input.equals("quit"));


    }

}
