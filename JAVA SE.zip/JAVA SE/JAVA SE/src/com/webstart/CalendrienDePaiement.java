package com.webstart;

import java.text.NumberFormat;
import java.util.Scanner;

public class CalendrienDePaiement {

    // Objectifs
    // L'idée c'est qu'en général nos méthode doivent avoir une dizaine de ligne de code max


    // Mise en place des fields de classe
    // fields defined at class level
    // available to all the class
    // on reviendra dessus plus tard pas de panique

    final static byte MONTHS_IN_YEAR = 12;
    final static byte PERCENT = 100;

    public static void main(String[] args) {

        // Améliorer un peu l'application
        // Montrer aux élèves le résultats souhaités
        // Et afficher le reste à payer après chaque paiement (chaque mois)

        // Pour calculer le reste à payer seulon le mois en cours
        // la formule est la suivante :

        // The next formula is used to calculate the remaining loan balance (B) of a fixed payment loan after p months.
        // B = L[(1 + c)n - (1 + c)p]/[(1 + c)n - 1]

        // Where
        /*
            c = monthly interest
            L = Loan amount
            P = Number of payment we have made
            n = The total number of payment
         n*/

        int amount = (int) readNumber("Montant : ", 1000, 1_000_000);
        float annualInterest = (float) readNumber("Intérêt annuel :", 1, 30);
        byte years = (byte) readNumber("Nombre d'années : ", 1, 30);

        double mortgage =  calculateMortgage(amount, annualInterest, years);

        String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println(); // on ajoute une line vide
        System.out.println("Remboursement mensuel de l'emprunt");
        System.out.println("--------");
        System.out.println("Montant des mensualités: " + mortgageFormatted);

        System.out.println();
        System.out.println("Calendrien de paiement : ");
        System.out.println("-------------------------");

        for(short month = 1; month <= years * MONTHS_IN_YEAR; month++) {
            double balance = calculateBalance(amount, annualInterest, years, month);
            System.out.println(NumberFormat.getCurrencyInstance().format(balance));
        }
    }

    public static double calculateMortgage(int amount, float annualInterest, byte years) {

        /* final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;*/

        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        double mortgage = amount
                * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return mortgage;

    }

    public static double readNumber(String prompt, double min, double max) {
        Scanner scanner = new Scanner(System.in);
        double value;
        while(true) {
            System.out.print(prompt);
            value = scanner.nextFloat();
            if(value >= min && value <= max)
                break;
            System.out.println("Enter a value between " + min + " and " + max );
        }

        return value;
    }

    // La méthode qui permettra de calculer le reste à payer
    public static double calculateBalance(
            int amount,
            float annualInterest,
            byte years,
            short numberOfPaymentMade) {

        // Pour éviter la répétition du code
        // Nous allons définir ces constantes au niveau de la classe
        // Elles vont devenir des fields
        // Des champs

/*        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;*/

        // Pour éviter de répéter ce code ci dessous on pourrait les mettre dans la méthode main
        // le nombre de paiment et l'interet mensuel ne change jamais

        // Même si on duplique le code ici et dans la méthode calculateMortGage
        // le code ne bougera pas, on l'appel juste à deux endroits différents
        // donc même si on voulait créer une autre application
        // ou modifier le code ca n'aurait pas d'impact
        // car c'est constant
        // plus tard avec la programmation objet on verra comment améliorer ca
        // pour vraiment éviter la duplication de code

        short numberOfPayments = (short) (years * MONTHS_IN_YEAR);
        float monthlyInterest = annualInterest / PERCENT / MONTHS_IN_YEAR;

        // B = L[(1 + c)n - (1 + c)p]/[(1 + c)n - 1]

        double balance = amount
                * (Math.pow(1 + monthlyInterest, numberOfPayments) - Math.pow(1 + monthlyInterest, numberOfPaymentMade))
                / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return balance;
    }
}
