package com.webstart;

public class ComparisonOperators {

    public static void main(String[] args) {

        int x = 1;
        int y = 1;

        System.out.println(x == y);
        System.out.println(x != y);
        System.out.println(x > y);
        System.out.println(x < y);
        System.out.println(x >= y);
        System.out.println(x <= y);

    }

}
