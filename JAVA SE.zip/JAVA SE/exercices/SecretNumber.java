package com.webstart;

import java.util.Random;
import java.util.Scanner;

public class SecretNumber {

    public static void main(String[] args) {

        // Trouver un chiffre secret

        // Générer aléatoirement un chiffre secret (1, 10)

        // et l'internaute aura 3 essais pour trouver ce chiffre secret

        // Si le chiffre secret est trouvé avant d'avoir écouler les trois chances la partie s'arrête c'est gagné
        // Si le chiffre secret n'est pas trouvé avant d'avoir écouler les trois chances la partie s'arrête c'est perdu

        // Si le chiffre proposé par l'internaute et plus petit que le chiffre secret, lui indiquer par un msg avec son
        // nombre de points de vie restant

        // Si le chiffre proposé par l'internaute et plus grand que le chiffre secret, lui indiquer par un msg avec son
        // nombre de points de vie restant

        // BONUS
        // Tant que l'internaute ne nous donne pas un chiffre compris entre 1 et 10 on lui repose la question
        // sans lui faire perdre de points de vie

        // Si l'internaute nous rentre pas un int
        // on lui dit et on lui repose la question

        Random random = new Random();

        int secret_number = random.nextInt(10) + 1;
        System.out.println(secret_number);

        Scanner scanner = new Scanner(System.in);

        int lifePoints = 3;
        int res;

        while (lifePoints > 0) {
            System.out.print("Please give us you secret number : ");

            String response = scanner.next();
            if(!response.matches("\\d+")) {
                System.out.println("Please give an integer value !");
                continue;
            } else {
                res = Integer.parseInt(response);
            }

            if(res > 10 || res < 1) {
                System.out.println("Please enter a number between 1 and 10, you still have x life points");
                continue;
            }

            if (res == secret_number) {
                System.out.println("You won the game !");
                break;
            } else if (res < secret_number) {
                System.out.println("You number is to low, you still have x life points");
            } else {
                System.out.println("You number is to high, you still have x life points");
            }

            lifePoints--;
        }

        if (lifePoints <= 0) {
            System.out.println("You lost the game");
        }
    }


}
