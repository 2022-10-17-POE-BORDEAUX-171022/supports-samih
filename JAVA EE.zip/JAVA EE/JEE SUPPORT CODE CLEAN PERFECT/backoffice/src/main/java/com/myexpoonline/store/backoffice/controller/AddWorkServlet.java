/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.myexpoonline.store.backoffice.controller;

import com.myexpoonline.store.core.entity.Work;
import com.myexpoonline.store.core.entity.Author;
import com.myexpoonline.store.core.entity.Catalogue;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Optional;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author samihhabbani
 */
@WebServlet(name = "AddWorkServlet", urlPatterns = {"/add-work2"})
public class AddWorkServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet AddWorkServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet AddWorkServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        boolean success = true;
        
        String title = request.getParameter("title");
                
        String style = request.getParameter("style");
        String authorName = request.getParameter("author");
        String description = request.getParameter("description");
        
        RequestDispatcher dispatcherError = request.getRequestDispatcher("/work-added-error");
        RequestDispatcher dispatcherSuccess = request.getRequestDispatcher("/work-added-success");

        int year = 0;
        // si l'utilisateur ne m'a pas rentré un chiffre entier
        // pareil j'affiche un msg d'erreur
        try {
            year = Integer.parseInt(request.getParameter("year"));
        } catch(NumberFormatException e) {
            dispatcherError.forward(request, response);
            success = false;
        }

        // Je vérifie que l'oeuvre n'est pas déjà dans le catalogue 
        // si c'est le cas je délègue le message d'erreur à une autre servlet
        /*for(Work work : Catalogue.listOfWorks) {
            if(work.getAuthor().getName().equals(authorName)
                    && work.getTitle().equals(title)
                    && work.getYear() == year) {
                
                // WorkAddedErrorServlet va se charger de la réponse d'erreur
                dispatcherError.forward(request, response);
                success = false;
                
            }
        }*/
        
        // créer l'oeuvre
        Work newWork = new Work();
        newWork.setTitle(title);
        newWork.setYear(year);
        newWork.setDescription(description);
        newWork.setStyle(style);

        Author author = new Author();
        author.setName(authorName);

        newWork.setAuthor(author);
        newWork.setId(Work.lastId);
        
        Optional<Work> optionalWork = Catalogue.listOfWorks.stream().filter(
                work -> work.getTitle().equals(newWork.getTitle()) 
                        && work.getAuthor().getName().equals(newWork.getAuthor().getName())
                        && work.getYear() == newWork.getYear()
        ).findAny();
        
        // si j'ai une correspondance
        // ça veut dire que l'oeuvre est déjà dans le catalogue
        
        if(optionalWork.isPresent()) {
            success = false;
            dispatcherError.forward(request, response);
        }
        
        
        if(success) {

            Catalogue.listOfWorks.add(newWork);

            // je délègue le msg de confirmation d'ajout à WorkAddedSuccessServlet
            dispatcherSuccess.forward(request, response);
        }

        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
